<?php

if (isset($_POST["send"])) {
	header("Location: lenco.php");
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Pay with Lenco</title>
    <script src="https://pay.lenco.co/js/v1/inline.js"></script>
    <style>
        .lenco-pay-button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            border: none;
            cursor: pointer;
            font-size: 18px;
            width: 100%;
            max-width: 300px;
            margin: 20px auto;
            display: block;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <!-- Simple input form -->
    <input type="email" id="email" value="bartwelmwanza7@gmail.com" placeholder="Enter email" required><br>
    <input type="number" id="amount" value="1" placeholder="Amount in USD" required><br>
    <input type="tel" id="phone" value="+260973077465" placeholder="Phone number"><br>

    <button class="lenco-pay-button" onclick="getPaidWithLenco()">Pay with Lenco</button>

    <script>
        const exchangeRate = 1; // Change as needed
        const publicKey = 'pub-0b95822978bb2707b82154d9506a2dc22ceb654996e2312c'; // Get from Lenco
        const callbackBaseUrl = 'https://web.beecorp.site/beepay/lenco_callback.php'; // Your callback handler

        function getPaidWithLenco() {
            const email = document.getElementById("email").value;
            const amountUSD = parseFloat(document.getElementById("amount").value);
            const phone = document.getElementById("phone").value;
            const amountZMW = amountUSD * exchangeRate;
            const reference = 'ref-' + Date.now();

            LencoPay.getPaid({
                key: publicKey,
                reference: reference,
                email: email,
                amount: amountZMW,
                currency: "ZMW",
                customer: {
                    firstName: "myname",
                    lastName: "mylastname",
                    phone: phone
                },
                onSuccess: function(response) {
                    window.location = callbackBaseUrl + "?reference=" + response.reference;
                },
                onClose: function() {
                    alert('Payment was not completed.');
                }
            });
        }
    </script>
</body>
</html>
